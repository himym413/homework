"use strict";

const moviesBtn = document.querySelectorAll(".movie_btn");
let totalPrice = 0;
const totalPriceEl = document.querySelector(".movie_price_total .value");
totalPriceEl.innerHTML = 0;

moviesBtn.forEach(function (btn) {
  btn.addEventListener("click", function () {
    btn.setAttribute("disabled", "true");
    btn.style.backgroundColor = "grey";
    btn.style.cursor = "default";
    btn.parentElement.style.backgroundColor = "rgb(184, 180, 180)";

    // Changing total price
    let moviePrice = parseFloat(
      btn.previousElementSibling.querySelector("span").innerHTML
    );
    totalPrice += moviePrice;
    totalPriceEl.innerHTML = totalPrice;
  });
});
