"use strict";

const h1 = document.querySelector("h1");
const btn1 = document.querySelector(".btn1");
const btn2 = document.querySelector(".btn2");
const selectEl = document.querySelector("select");
const body = document.querySelector("body");

// Homework
// Adding events
// 1. Resize

const showWidth = () => console.log(window.innerWidth);

window.addEventListener("resize", showWidth);

// 2. Load

const showLoaded = () => alert("Page loaded!");

window.addEventListener("load", showLoaded);

// 3. Click

const changeBtnColor = () => btn1.classList.toggle("green");

btn1.addEventListener("click", changeBtnColor);

// 4. Mousemove

const showEvent = () => console.log("Mouse pointing at Button2");

btn2.addEventListener("mousemove", showEvent);

// 5. Keydown

const headerColorWhite = () => (h1.style.color = "white");

const headerColorBlack = () => (h1.style.color = "black");

window.addEventListener("keydown", function (e) {
  if (e.key === "w") headerColorWhite();
  if (e.key === "b") headerColorBlack();
});

// 6. Change
selectEl.addEventListener("change", function () {
  let paragraph = document.createElement("p");
  paragraph.innerText = "You made a change!";
  paragraph.style.textAlign = "center";
  body.appendChild(paragraph);
});
