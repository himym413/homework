let logo = document.querySelector(".lnXdpd");
if (logo) {
  logo.src = chrome.runtime.getURL("images/cysecor_logo.png");
  logo.srcset = chrome.runtime.getURL("images/cysecor_logo.png");
}

let logoSmall = document.querySelector(".logo a img");
if (logoSmall) {
  logoSmall.src = chrome.runtime.getURL("icons/icon48.png");
  logoSmall.style.width = "70px";
  logoSmall.style.height = "40px";
}
