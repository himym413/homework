"use strict";

const tasks = document.querySelectorAll(".task");
const taskContainer = document.querySelector(".task-container");
const btnAdd = document.querySelector(".add-task");
const inputField = document.getElementById("task-name");

const createTask = function (task) {
  const span = document.createElement("span");
  span.classList.add("remove-task");
  span.innerHTML = "\u00D7";
  task.appendChild(span);
};

const showNewTask = function () {
  const text = inputField.value;
  if (!text) {
    alert("You must write something!");
    return;
  }
  const newTask = document.createElement("LI");
  newTask.classList.add("task");
  newTask.innerHTML = text;
  taskContainer.appendChild(newTask);
  createTask(newTask);
  inputField.value = "";
};

tasks.forEach(createTask);

taskContainer.addEventListener("click", function (e) {
  e.target.classList.contains("remove-task") && e.target.parentElement.remove();
  e.target.classList.contains("task") &&
    e.target.classList.toggle("task-complete");
});

btnAdd.addEventListener("click", showNewTask);
inputField.addEventListener("keypress", function (e) {
  if (e.key === "Enter") showNewTask();
});
