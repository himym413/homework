"use strict";

const textTag = document.querySelector(".section1 h1");
const text = textTag.textContent;

let splittedText = text.split("");

textTag.innerHTML = "";

splittedText.forEach(function (letter) {
  if (letter === " ") {
    letter = "&nbsp;";
  }

  textTag.innerHTML += `<span>${letter}</span>`;
});

// Animate Header
let spans = textTag.querySelectorAll("span");

const animateHeader = function () {
  let k = 0;
  let interval = setInterval(() => {
    let singleSpan = spans[k];
    singleSpan.classList.add("fadeMove");

    k++;

    if (k === spans.length) {
      clearInterval(interval);
    }
  }, 70);
};

animateHeader();

let border = document.querySelector(".border-line");

let sectionForAnimation = document.querySelector(".section2 .images");

let leftImage = document.querySelector(".slideFromLeft");
let rightImage = document.querySelector(".slideFromRight");
let animationWidth = 0;

window.addEventListener("scroll", () => {
  if (this.oldScroll > this.scrollY) {
    animationWidth -= 1.5;
  } else {
    animationWidth += 1.5;
  }

  if (animationWidth >= 100) {
    animationWidth = 100;
  }

  if (animationWidth <= 0) {
    animationWidth = 0;
  }

  border.style.width = animationWidth + "%";

  this.oldScroll = this.scrollY;

  imageAnimation();
});

let imageAnimation = () => {
  imageAnimation = function () {}; // function only called once
  let sectionPosition = sectionForAnimation.getBoundingClientRect().top;
  let screenPosition = window.innerHeight / 1.3;

  if (sectionPosition < screenPosition) {
    leftImage.classList.add("animated");
    rightImage.classList.add("animated");
  }

  // console.log("SectionP: " + sectionPosition);
  // console.log("ScreenP: " + screenPosition);
};

// Homework

// 1. Animate Header

const animateHeaderBtn = document.querySelector(".btnAnimateHeader");

animateHeaderBtn.addEventListener("click", function () {
  spans.forEach((span) => span.classList.remove("fadeMove"));

  animateHeader();
});

// 2. Moving border line on + and -

document.addEventListener("keydown", function (e) {
  if (e.key === "+") {
    if (animationWidth >= 100) animationWidth = 100;
    else animationWidth += 5;
  }

  if (e.key === "-") {
    if (animationWidth === 0) animationWidth = 0;
    else animationWidth -= 5;
  }

  border.style.width = animationWidth + "%";
});

// 3. Adding images at the click of a button
const imgOneBtn = document.querySelector(".img_one__move");
const imgTwoBtn = document.querySelector(".img_two__move");

imgOneBtn.addEventListener("click", function () {
  leftImage.classList.toggle("animated");
});

imgTwoBtn.addEventListener("click", function () {
  rightImage.classList.toggle("animated");
});

// 4. Example with bouncing ball

const ball = document.querySelector(".ball");
const ballShadow = document.querySelector(".ball_shadow");

ball.addEventListener("click", function () {
  ball.classList.toggle("ballAnimated");
  ballShadow.classList.toggle("ballShadowAnimated");
});
